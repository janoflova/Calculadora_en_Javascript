else if(numero=="="){

// puede pasar que la operacion este completa, con dos operandos y un operador (esto se toma del input oculto)

  var posicion_signo_mas=numero_anterior.indexOf("+");
  var operando1=numero_anterior.substring(0,posicion_signo_mas-1);
  var operando2=numero_anterior.substring(posicion_signo_mas+1,numero_anterior.length);

  var resultado=sumar(operando1,operando2);
  document.getElementById("display").innerHTML=resultado;
  document.getElementById("input_oculto").value=resultado;   




 }   
  